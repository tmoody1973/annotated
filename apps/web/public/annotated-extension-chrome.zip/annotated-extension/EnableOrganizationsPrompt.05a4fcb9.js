var e,r;"function"==typeof(e=globalThis.define)&&(r=e,e=null),function(r,n,t,s,i){var o="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},a="function"==typeof o[s]&&o[s],l=a.cache||{},c="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function d(e,n){if(!l[e]){if(!r[e]){var t="function"==typeof o[s]&&o[s];if(!n&&t)return t(e,!0);if(a)return a(e,!0);if(c&&"string"==typeof e)return c(e);var i=Error("Cannot find module '"+e+"'");throw i.code="MODULE_NOT_FOUND",i}u.resolve=function(n){var t=r[e][1][n];return null!=t?t:n},u.cache={};var p=l[e]=new d.Module(e);r[e][0].call(p.exports,u,p,p.exports,this)}return l[e].exports;function u(e){var r=u.resolve(e);return!1===r?{}:d(r)}}d.isParcelRequire=!0,d.Module=function(e){this.id=e,this.bundle=d,this.exports={}},d.modules=r,d.cache=l,d.parent=a,d.register=function(e,n){r[e]=[function(e,r){r.exports=n},{}]},Object.defineProperty(d,"root",{get:function(){return o[s]}}),o[s]=d;for(var p=0;p<n.length;p++)d(n[p]);if(t){var u=d(t);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):i&&(this[i]=u)}}({bPCqu:[function(e,r,n){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(n),t.export(n,"EnableOrganizationsPrompt",()=>g);var s=e("../../../contexts/OptionsContext.js"),i=e("../../../contexts/EnvironmentContext.js"),o=e("../../../styledSystem/InternalThemeProvider.js"),a=e("../../../customizables/index.js"),l=e("../../../elements/Modal.js"),c=e("../../../elements/Portal.js"),d=e("../shared.js"),p=e("react"),u=t.interopDefault(p),h=e("@clerk/shared/react"),x=e("@emotion/react/jsx-runtime"),f=e("@emotion/react");let m=({caller:e,onSuccess:r,onClose:n})=>{let t=(0,h.useClerk)(),[o,u]=(0,p.useState)(!1),[m,g]=(0,p.useState)(!1),[C,v]=(0,p.useState)(null),[k,_]=(0,p.useState)(!1),$=(0,p.useRef)(null),E=(0,i.useEnvironment)(),F=(0,p.useId)(),O=(0,s.useOptions)(),I=O.__internal_keyless_claimKeylessApplicationUrl,M=O.__internal_keyless_copyInstanceKeysUrl,R=!!I&&!!M,L=null!==E.authConfig.claimedAt,U=m&&R&&!L,T=!e.startsWith("use"),D=void 0!==E?.organizationSettings.forceOrganizationSelection;return(0,x.jsx)(c.Portal,{children:(0,x.jsx)(l.Modal,{canCloseModal:!1,containerSx:()=>({alignItems:"center"}),initialFocusRef:$,children:(0,x.jsxs)(d.PromptContainer,{sx:()=>({display:"flex",flexDirection:"column",width:"30rem",maxWidth:"calc(100vw - 2rem)"}),children:[(0,x.jsxs)(a.Flex,{direction:"col",sx:e=>({padding:`${e.sizes.$4} ${e.sizes.$6}`,paddingBottom:e.sizes.$4,gap:e.sizes.$2}),children:[(0,x.jsxs)(a.Flex,{as:"header",align:"center",sx:e=>({gap:e.sizes.$2}),children:[(0,x.jsx)(B,{isEnabled:m}),(0,x.jsx)("h1",{css:[d.basePromptElementStyles,(0,f.css)`
                    color: white;
                    font-size: 0.875rem;
                    font-weight: 500;
                    outline: none;
                  `],tabIndex:-1,ref:$,children:m?"Organizations feature enabled":"Organizations feature required"})]}),(0,x.jsx)(a.Flex,{direction:"col",align:"start",sx:e=>({gap:e.sizes.$0x5}),children:m?(0,x.jsxs)("p",{css:[d.basePromptElementStyles,(0,f.css)`
                      color: #b4b4b4;
                      font-size: 0.8125rem;
                      font-weight: 400;
                      line-height: 1.3;
                    `],children:[U?C?`Organizations are now enabled and a default organization named "${C}" was created. Claim your application to save this configuration and access the full dashboard.`:"Organizations are now enabled! Claim your application to save this configuration and access the full dashboard.":t.user&&C?`The Organizations feature has been enabled for your application. A default organization named "${C}" was created automatically. You can manage or rename it in your`:"The Organizations feature has been enabled for your application. You can manage it in your",!U&&(0,x.jsxs)(x.Fragment,{children:[" ",(0,x.jsx)(P,{href:"https://dashboard.clerk.com/~/organizations-settings",target:"_blank",rel:"noopener noreferrer",children:"dashboard"}),"."]})]}):(0,x.jsxs)(x.Fragment,{children:[(0,x.jsxs)("p",{id:F,css:[d.basePromptElementStyles,(0,f.css)`
                        color: #b4b4b4;
                        font-size: 0.8125rem;
                        font-weight: 400;
                        line-height: 1.23;
                      `],children:["Enable Organizations to use"," ",(0,x.jsx)("code",{css:[d.basePromptElementStyles,(0,f.css)`
                          font-size: 0.75rem;
                          color: white;
                          font-family: monospace;
                          line-height: 1.23;
                        `],children:T?`<${e} />`:e})," "]}),(0,x.jsx)(P,{href:"https://clerk.com/docs/guides/organizations/overview",target:"_blank",rel:"noopener noreferrer",children:"Learn more"})]})}),D&&!m&&(0,x.jsx)(a.Flex,{sx:e=>({marginTop:e.sizes.$2}),direction:"col",children:(0,x.jsxs)(z,{value:k?"optional":"required",onChange:e=>_("optional"===e),labelledBy:F,children:[(0,x.jsx)(S,{value:"required",label:(0,x.jsxs)(a.Flex,{wrap:"wrap",sx:e=>({columnGap:e.sizes.$2,rowGap:e.sizes.$1}),children:[(0,x.jsx)("span",{children:"Membership required"}),(0,x.jsx)(y,{children:"Standard"})]}),description:(0,x.jsxs)(x.Fragment,{children:[(0,x.jsx)("span",{className:"block",children:"Users need to belong to at least one organization."}),(0,x.jsx)("span",{children:"Common for most B2B SaaS applications"})]})}),(0,x.jsx)(S,{value:"optional",label:"Membership optional",description:"Users can work outside of an organization with a personal account"})]})})]}),(0,x.jsx)("span",{css:(0,f.css)`
              height: 1px;
              display: block;
              width: calc(100% - 2px);
              margin-inline: auto;
              background-color: #151515;
              box-shadow: 0px 1px 0px 0px #424242;
            `}),(0,x.jsx)(a.Flex,{justify:"center",sx:e=>({padding:`${e.sizes.$4} ${e.sizes.$6}`,gap:e.sizes.$3,justifyContent:"flex-end"}),children:m?U?(0,x.jsxs)(x.Fragment,{children:[(0,x.jsx)(w,{variant:"outline",onClick:()=>{r?.()},children:t.user?"Continue":"I\u2019ll do it later"}),(0,x.jsx)(P,{href:I,target:"_blank",rel:"noopener noreferrer",onClick:e=>{if(I){let r=new URL(I);r.searchParams.append("return_url",window.location.href),e.currentTarget.href=r.href}t.__internal_closeEnableOrganizationsPrompt?.()},css:(0,f.css)`
                      ${b}
                      ${j}
                      color: #fde047;
                      text-decoration: none;
                    `,children:"Claim your application"})]}):(0,x.jsx)(w,{variant:"solid",onClick:()=>{t.user?r?.():(t.redirectToSignIn(),t.__internal_closeEnableOrganizationsPrompt?.())},children:t.user?"Continue":"Sign in to continue"}):(0,x.jsxs)(x.Fragment,{children:[(0,x.jsx)(w,{variant:"outline",onClick:()=>{t?.__internal_closeEnableOrganizationsPrompt?.(),n?.()},children:"I'll remove it myself"}),(0,x.jsx)(w,{variant:"solid",onClick:()=>{u(!0);let e={enable_organizations:!0};D&&(e.organization_allow_personal_accounts=k),E.__internal_enableEnvironmentSetting(e).then(async()=>{v((await t.user?.getOrganizationMemberships())?.data[0]?.organization.name??null),g(!0),u(!1)}).catch(()=>{u(!1)})},disabled:o,children:"Enable Organizations"})]})})]})})})},g=e=>(0,x.jsx)(o.InternalThemeProvider,{children:(0,x.jsx)(m,{...e})}),b=(0,f.css)`
  ${d.basePromptElementStyles};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 1.75rem;
  padding: 0.375rem 0.625rem;
  border-radius: 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
  letter-spacing: 0.12px;
  color: white;
  text-shadow: 0px 1px 2px rgba(0, 0, 0, 0.32);
  white-space: nowrap;
  user-select: none;
  color: white;
  outline: none;

  &:not(:disabled) {
    transition: 120ms ease-in-out;
    transition-property: background-color, border-color, box-shadow, color;
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  &:focus-visible:not(:disabled) {
    outline: 2px solid white;
    outline-offset: 2px;
  }
`,j=(0,f.css)`
  background: linear-gradient(180deg, rgba(0, 0, 0, 0) 30.5%, rgba(0, 0, 0, 0.05) 100%), #454545;
  box-shadow:
    0 0 3px 0 rgba(253, 224, 71, 0) inset,
    0 0 0 1px rgba(255, 255, 255, 0.04) inset,
    0 1px 0 0 rgba(255, 255, 255, 0.04) inset,
    0 0 0 1px rgba(0, 0, 0, 0.12),
    0 1.5px 2px 0 rgba(0, 0, 0, 0.48);

  &:hover:not(:disabled) {
    background: linear-gradient(180deg, rgba(0, 0, 0, 0) 30.5%, rgba(0, 0, 0, 0.15) 100%), #5f5f5f;
    box-shadow:
      0 0 3px 0 rgba(253, 224, 71, 0) inset,
      0 0 0 1px rgba(255, 255, 255, 0.04) inset,
      0 1px 0 0 rgba(255, 255, 255, 0.04) inset,
      0 0 0 1px rgba(0, 0, 0, 0.12),
      0 1.5px 2px 0 rgba(0, 0, 0, 0.48);
  }
`,C={solid:j,outline:(0,f.css)`
  border: 1px solid rgba(118, 118, 132, 0.25);
  background: rgba(69, 69, 69, 0.1);

  &:hover:not(:disabled) {
    border-color: rgba(118, 118, 132, 0.5);
  }
`},w=(0,p.forwardRef)(({variant:e="solid",...r},n)=>(0,x.jsx)("button",{ref:n,type:"button",css:[b,C[e]],...r})),y=({children:e})=>(0,x.jsx)("span",{css:(0,f.css)`
        ${d.basePromptElementStyles};
        display: inline-flex;
        align-items: center;
        padding: 0.125rem 0.375rem;
        border-radius: 0.25rem;
        font-size: 0.6875rem;
        font-weight: 500;
        line-height: 1.23;
        background-color: #ebebeb;
        color: #2b2b34;
        white-space: nowrap;
      `,children:e}),[v,k]=(0,h.createContextAndHook)("RadioGroupContext"),z=({value:e,onChange:r,children:n,labelledBy:t})=>{let s=(0,p.useId)(),i=(0,u.default).useMemo(()=>({value:{name:s,value:e,onChange:r}}),[s,e,r]);return(0,x.jsx)(v.Provider,{value:i,children:(0,x.jsx)(a.Flex,{role:"radiogroup",direction:"col",gap:3,"aria-orientation":"vertical","aria-labelledby":t,children:n})})},_="1rem",$="0.5rem",S=({value:e,label:r,description:n})=>{let{name:t,value:s,onChange:i}=k(),o=(0,p.useId)(),l=e===s;return(0,x.jsxs)(a.Flex,{direction:"col",gap:1,children:[(0,x.jsxs)("label",{css:(0,f.css)`
          ${d.basePromptElementStyles};
          display: flex;
          align-items: flex-start;
          gap: ${$};
          cursor: pointer;
          user-select: none;

          &:has(input:focus-visible) > span:first-of-type {
            outline: 2px solid white;
            outline-offset: 2px;
          }

          &:hover:has(input:not(:checked)) > span:first-of-type {
            background-color: rgba(255, 255, 255, 0.08);
          }

          &:hover:has(input:checked) > span:first-of-type {
            background-color: rgba(108, 71, 255, 0.8);
            background-color: color-mix(in srgb, #6c47ff 80%, transparent);
          }
        `,children:[(0,x.jsx)("input",{type:"radio",name:t,value:e,checked:l,onChange:()=>i(e),"aria-describedby":n?o:void 0,css:(0,f.css)`
            ${d.basePromptElementStyles};
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border-width: 0;
          `}),(0,x.jsx)("span",{"aria-hidden":"true",css:(0,f.css)`
            ${d.basePromptElementStyles};
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: ${_};
            height: ${_};
            margin-top: 0.125rem;
            flex-shrink: 0;
            border-radius: 50%;
            border: 1px solid rgba(255, 255, 255, 0.3);
            background-color: transparent;
            transition: 120ms ease-in-out;
            transition-property: border-color, background-color, box-shadow;

            ${l&&(0,f.css)`
              border-width: 2px;
              border-color: #6c47ff;
              background-color: #6c47ff;
              background-color: color-mix(in srgb, #6c47ff 100%, transparent);
              box-shadow: 0 0 0 2px rgba(108, 71, 255, 0.2);
            `}

            &::after {
              content: '';
              position: absolute;
              width: 0.375rem;
              height: 0.375rem;
              border-radius: 50%;
              background-color: white;
              opacity: ${l?1:0};
              transform: scale(${l?1:0});
              transition: 120ms ease-in-out;
              transition-property: opacity, transform;
            }
          `}),(0,x.jsx)("span",{css:[d.basePromptElementStyles,(0,f.css)`
              font-size: 0.875rem;
              font-weight: 500;
              line-height: 1.25;
              color: white;
            `],children:r})]}),n&&(0,x.jsx)("span",{id:o,css:[d.basePromptElementStyles,(0,f.css)`
              padding-inline-start: calc(${_} + ${$});
              font-size: 0.75rem;
              line-height: 1.33;
              color: #c3c3c6;
              text-wrap: pretty;
            `],children:n})]})},P=(0,p.forwardRef)(({children:e,css:r,...n},t)=>(0,x.jsx)("a",{ref:t,...n,css:[d.basePromptElementStyles,(0,f.css)`
            color: #a8a8ff;
            font-size: inherit;
            font-weight: 500;
            line-height: 1.3;
            font-size: 0.8125rem;
            min-width: 0;
          `,r],children:e})),B=({isEnabled:e})=>{let[r,n]=(0,p.useState)(0);(0,p.useLayoutEffect)(()=>{if(e){n(e=>0===e?180:0);return}let r=setInterval(()=>{n(e=>0===e?180:0)},2e3);return()=>clearInterval(r)},[e]);let t="idle",s="warning";e&&(0===r?(t="success",s="warning"):(s="success",t="idle"));let i=e=>{switch(e){case"idle":return(0,x.jsx)(d.ClerkLogoIcon,{});case"success":return(0,x.jsx)(d.PromptSuccessIcon,{css:(0,f.css)`
              width: 1.25rem;
              height: 1.25rem;
            `});case"warning":return(0,x.jsxs)("svg",{css:(0,f.css)`
              width: 1.25rem;
              height: 1.25rem;
            `,viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,x.jsx)("path",{opacity:"0.2",d:"M17.25 10C17.25 14.0041 14.0041 17.25 10 17.25C5.99594 17.25 2.75 14.0041 2.75 10C2.75 5.99594 5.99594 2.75 10 2.75C14.0041 2.75 17.25 5.99594 17.25 10Z",fill:"#EAB308"}),(0,x.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 13.5899 6.41015 16.5 10 16.5C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10Z",fill:"#EAB308"}),(0,x.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 6C10.5523 6 11 6.44772 11 7V9C11 9.55228 10.5523 10 10 10C9.44772 10 9 9.55228 9 9V7C9 6.44772 9.44772 6 10 6Z",fill:"#EAB308"}),(0,x.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 12C10.5523 12 11 12.4477 11 13V13.01C11 13.5623 10.5523 14.01 10 14.01C9.44772 14.01 9 13.5623 9 13.01V13C9 12.4477 9.44772 12 10 12Z",fill:"#EAB308"})]})}};return(0,x.jsx)("div",{css:(0,f.css)`
        perspective: 1000px;
        width: 1.25rem;
        height: 1.25rem;
      `,children:(0,x.jsxs)("div",{css:(0,f.css)`
          position: relative;
          width: 100%;
          height: 100%;
          transform-style: preserve-3d;
          transition: transform 0.6s ease-in-out;
          transform: rotateY(${r}deg);

          @media (prefers-reduced-motion: reduce) {
            transition: none;
          }
        `,children:[(0,x.jsx)("span",{"aria-hidden":!0,css:(0,f.css)`
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            -webkit-font-smoothing: antialiased;
            transform: rotateY(0deg);
          `,children:i(t)}),(0,x.jsx)("span",{"aria-hidden":!0,css:(0,f.css)`
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            transform: rotateY(180deg);
            display: flex;
            align-items: center;
            justify-content: center;
            -webkit-font-smoothing: antialiased;
          `,children:i(s)})]})})}},{"../../../contexts/OptionsContext.js":"BSUzg","../../../contexts/EnvironmentContext.js":"5gYpV","../../../styledSystem/InternalThemeProvider.js":"kMXOz","../../../customizables/index.js":"6q3X6","../../../elements/Modal.js":"ejFh4","../../../elements/Portal.js":"3ldDu","../shared.js":"2CKGR",react:"eZJBL","@clerk/shared/react":"ewcfK","@emotion/react/jsx-runtime":"6s44V","@emotion/react":"g9DoO","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"3ldDu":[function(e,r,n){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(n),t.export(n,"Portal",()=>a);var s=e("react"),i=t.interopDefault(s),o=e("react-dom");let a=e=>{let r=(0,i.default).useRef(document.createElement("div"));return(0,i.default).useEffect(()=>(document.body.appendChild(r.current),()=>{document.body.removeChild(r.current)}),[]),(0,o.createPortal)(e.children,r.current)}},{react:"eZJBL","react-dom":"gjQTV","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"2CKGR":[function(e,r,n){var t=e("@parcel/transformer-js/src/esmodule-helpers.js");t.defineInteropFlag(n),t.export(n,"ClerkLogoIcon",()=>p),t.export(n,"PromptContainer",()=>a),t.export(n,"PromptSuccessIcon",()=>c),t.export(n,"basePromptElementStyles",()=>l),t.export(n,"handleDashboardUrlParsing",()=>d);var s=e("../../customizables/index.js"),i=e("@emotion/react/jsx-runtime"),o=e("@emotion/react");function a({children:e,sx:r,...n}){return(0,i.jsx)(s.Flex,{sx:e=>[{borderRadius:"1.25rem",fontFamily:e.fonts.$main,background:"linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0) 100%), #1f1f1f",boxShadow:"0px 0px 0px 0.5px #2F3037 inset, 0px 1px 0px 0px rgba(255, 255, 255, 0.08) inset, 0px 0px 0.8px 0.8px rgba(255, 255, 255, 0.20) inset, 0px 0px 0px 0px rgba(255, 255, 255, 0.72), 0px 16px 36px -6px rgba(0, 0, 0, 0.36), 0px 6px 16px -2px rgba(0, 0, 0, 0.20);"},r],...n,children:e})}let l=(0,o.css)`
  box-sizing: border-box;
  padding: 0;
  margin: 0;
  background: none;
  border: none;
  line-height: 1.5;
  font-family:
    -apple-system,
    BlinkMacSystemFont,
    avenir next,
    avenir,
    segoe ui,
    helvetica neue,
    helvetica,
    Cantarell,
    Ubuntu,
    roboto,
    noto,
    arial,
    sans-serif;
  text-decoration: none;
`;function c(e){return(0,i.jsx)("svg",{...e,viewBox:"0 0 16 17",fill:"none","aria-hidden":!0,xmlns:"http://www.w3.org/2000/svg",children:(0,i.jsxs)("g",{opacity:"0.88",children:[(0,i.jsx)("path",{d:"M13.8002 8.20039C13.8002 8.96206 13.6502 9.71627 13.3587 10.42C13.0672 11.1236 12.64 11.763 12.1014 12.3016C11.5628 12.8402 10.9234 13.2674 10.2198 13.5589C9.51607 13.8504 8.76186 14.0004 8.0002 14.0004C7.23853 14.0004 6.48432 13.8504 5.78063 13.5589C5.07694 13.2674 4.43756 12.8402 3.89898 12.3016C3.3604 11.763 2.93317 11.1236 2.64169 10.42C2.35022 9.71627 2.2002 8.96206 2.2002 8.20039C2.2002 6.66214 2.81126 5.18688 3.89898 4.09917C4.98669 3.01146 6.46194 2.40039 8.0002 2.40039C9.53845 2.40039 11.0137 3.01146 12.1014 4.09917C13.1891 5.18688 13.8002 6.66214 13.8002 8.20039Z",fill:"#22C543",fillOpacity:"0.16"}),(0,i.jsx)("path",{d:"M6.06686 8.68372L7.51686 10.1337L9.93353 6.75039M13.8002 8.20039C13.8002 8.96206 13.6502 9.71627 13.3587 10.42C13.0672 11.1236 12.64 11.763 12.1014 12.3016C11.5628 12.8402 10.9234 13.2674 10.2198 13.5589C9.51607 13.8504 8.76186 14.0004 8.0002 14.0004C7.23853 14.0004 6.48432 13.8504 5.78063 13.5589C5.07694 13.2674 4.43756 12.8402 3.89898 12.3016C3.3604 11.763 2.93317 11.1236 2.64169 10.42C2.35022 9.71627 2.2002 8.96206 2.2002 8.20039C2.2002 6.66214 2.81126 5.18688 3.89898 4.09917C4.98669 3.01146 6.46194 2.40039 8.0002 2.40039C9.53845 2.40039 11.0137 3.01146 12.1014 4.09917C13.1891 5.18688 13.8002 6.66214 13.8002 8.20039Z",stroke:"#22C543",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round"})]})})}function d(e){let r=new URL(e).href.match(/^https?:\/\/(.*?)\/apps\/app_(.+?)\/instances\/ins_(.+?)(?:\/.*)?$/);if(!r)throw Error("Invalid value Dashboard URL structure");return{baseDomain:`https://${r[1]}`,appId:`app_${r[2]}`,instanceId:`ins_${r[3]}`}}function p(){return(0,i.jsxs)("svg",{width:"1rem",height:"1.25rem",viewBox:"0 0 16 20",fill:"none","aria-hidden":!0,xmlns:"http://www.w3.org/2000/svg",children:[(0,i.jsxs)("g",{filter:"url(#filter0_i_438_501)",children:[(0,i.jsx)("path",{d:"M10.4766 9.99979C10.4766 11.3774 9.35978 12.4942 7.98215 12.4942C6.60452 12.4942 5.48773 11.3774 5.48773 9.99979C5.48773 8.62216 6.60452 7.50537 7.98215 7.50537C9.35978 7.50537 10.4766 8.62216 10.4766 9.99979Z",fill:"#BBBBBB"}),(0,i.jsx)("path",{d:"M12.4176 3.36236C12.6676 3.52972 12.6889 3.88187 12.4762 4.09457L10.6548 5.91595C10.4897 6.08107 10.2336 6.10714 10.0257 6.00071C9.41273 5.68684 8.71811 5.50976 7.98214 5.50976C5.5024 5.50976 3.49219 7.51998 3.49219 9.99972C3.49219 10.7357 3.66926 11.4303 3.98314 12.0433C4.08957 12.2511 4.06349 12.5073 3.89837 12.6724L2.07699 14.4938C1.86429 14.7065 1.51215 14.6851 1.34479 14.4352C0.495381 13.1666 0 11.641 0 9.99972C0 5.5913 3.57373 2.01758 7.98214 2.01758C9.62345 2.01758 11.1491 2.51296 12.4176 3.36236Z",fill:"#8F8F8F"}),(0,i.jsx)("path",{d:"M12.4762 15.905C12.6889 16.1177 12.6675 16.4698 12.4176 16.6372C11.149 17.4866 9.62342 17.982 7.9821 17.982C6.34078 17.982 4.81516 17.4866 3.54661 16.6372C3.29666 16.4698 3.27531 16.1177 3.48801 15.905L5.30938 14.0836C5.4745 13.9185 5.73066 13.8924 5.93851 13.9988C6.55149 14.3127 7.24612 14.4898 7.9821 14.4898C8.71808 14.4898 9.4127 14.3127 10.0257 13.9988C10.2335 13.8924 10.4897 13.9185 10.6548 14.0836L12.4762 15.905Z",fill:"#BBBBBB"})]}),(0,i.jsx)("defs",{children:(0,i.jsxs)("filter",{id:"filter0_i_438_501",x:"0",y:"1.86758",width:"12.6217",height:"16.1144",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB",children:[(0,i.jsx)("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),(0,i.jsx)("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),(0,i.jsx)("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),(0,i.jsx)("feOffset",{dy:"-0.15"}),(0,i.jsx)("feGaussianBlur",{stdDeviation:"0.15"}),(0,i.jsx)("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),(0,i.jsx)("feColorMatrix",{type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"}),(0,i.jsx)("feBlend",{mode:"normal",in2:"shape",result:"effect1_innerShadow_438_501"})]})})]})}},{"../../customizables/index.js":"6q3X6","@emotion/react/jsx-runtime":"6s44V","@emotion/react":"g9DoO","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}]},[],null,"parcelRequireca48"),globalThis.define=r;